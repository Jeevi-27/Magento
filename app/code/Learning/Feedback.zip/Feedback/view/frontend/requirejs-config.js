var config = {
    map: {
        '*': {
            scroller: 'Learning_Feedback/js/scroller',
            carousel: 'Learning_Feedback/js/owl.carousel.min'
        }
    }
};